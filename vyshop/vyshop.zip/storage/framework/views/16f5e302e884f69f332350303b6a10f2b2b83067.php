
<?php $__env->startSection('content'); ?>
    <a name="subscribe"></a>
    <div id="fb-root"></div>
    <?php $__currentLoopData = $product_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $productr_details): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="product-details">
            <!--product-details-->
            <div class="col-sm-5">
                <div class="view-product">
                    <img src="<?php echo e(URL::to('/public/uploads/product/' . $productr_details->product_image)); ?>" alt="" />
                </div>
            </div>
            <div class="col-sm-7">
                <div class="product-information">
                    <!--/product-information-->
                    <img src="images/product-details/new.jpg" class="newarrival" alt="" />
                    <h2 style="size:18sp"><?php echo e($productr_details->product_name); ?></h2>
                    <p>ID sản phẩm: <?php echo e($productr_details->product_id); ?></p>
                    <img src="<?php echo e(URL::to('/public/frontend/images/rating.png')); ?>" alt="" />
                    <form action="<?php echo e(URL::to('/save-cart')); ?>" method="POST">
                        <?php echo e(csrf_field()); ?>

                        <span>
                            <span><?php echo e(number_format($productr_details->product_price) . ' ' . 'VND'); ?></span>
                            <br>
                            <label>Số lượng:</label>
                            <input style="width:50px;height:50px" name="qty" type="number" min="1" value="1" />
                            <input name="productid_hidden" type="hidden" value="<?php echo e($productr_details->product_id); ?>" />
                            <button type="submit" class="btn btn-fefault cart">
                                <i class="fa fa-shopping-cart"></i>
                                + Giỏ hàng
                            </button>
                        </span>
                    </form>
                    <p><b>Tình trạng:</b> Còn hàng</p>
                    
                    <p><b>Thương hiệu:</b> <?php echo e($productr_details->brand_product->brand_name); ?></p>
                    <p><b>Danh mục:</b> <?php echo e($productr_details->category_product->category_name); ?></p>
                    <div class="contactinfo" style="padding-left: 18px">
                        <ul class="nav nav-pills">
                            <li>
                                <div class="fb-share-button" data-href="http://localhost/vyshop/" data-layout="button_count"
                                    data-size="small"><a target="_blank"
                                        href="https://www.facebook.com/sharer/sharer.php?u=<?php echo e($url_canonical); ?>;src=sdkpreparse"
                                        class="fb-xfbml-parse-ignore">Chia sẻ</a></div>
                            </li>
                            <li>
                                <div class="fb-like" data-href="<?php echo e($url_canonical); ?>" data-width=""
                                    data-layout="button_count" data-action="like" data-size="small" data-share="false">
                                </div>
                            </li>
                        </ul>
                    </div>
                </div>
                <!--/product-information-->
            </div>
        </div>
        <!--/product-details-->
        <div class="category-tab shop-details-tab">
            <!--category-tab-->
            <div class="col-sm-12">
                <ul class="nav nav-tabs">
                    <li class="active"><a href="#details" data-toggle="tab">Chi tiết sản phẩm</a></li>
                    <li><a href="#comment" data-toggle="tab">Bình luận</a></li>
                </ul>
            </div>
            <div class="tab-content">
                <div class="tab-pane fade active in" id="details">
                    <p><?php echo $productr_details->product_desc; ?></p>
                    
                </div>
                <div class="tab-pane fade" id="comment">
                    <div class="fb-comments" data-href="<?php echo e($url_canonical); ?>" data-width="" data-numposts="5"></div>
                </div>
            </div>
        </div>
        <!--/category-tab-->
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <div class="recommended_items">
        <!--recommended_items-->
        <h2 class="title text-center">Sản phẩm liên quan<h2>
                <?php $__currentLoopData = $relate; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $related): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e(URL::to('/chi-tiet-san-pham/' . $related->meta_keywords)); ?>">
                        <div class="col-sm-4">
                            <div class="product-image-wrapper">
                                <div class="single-products">
                                    <div class="productinfo text-center">
                                        <form action="<?php echo e(URL::to('/save-cart')); ?>" method="post">
                                            <?php echo e(csrf_field()); ?>

                                            <img src="<?php echo e(URL::to('public/uploads/product/' . $related->product_image)); ?>"
                                                alt="" />
                                            <input name="productid_hidden" type="hidden"
                                                value="<?php echo e($related->product_id); ?>" />
                                            <input name="qty" type="hidden" value="1" />
                                            <h2><?php echo e(number_format($related->product_price) . ' ' . 'vnđ'); ?></h2>
                                            <p><?php echo e($related->product_name); ?></p>
                                            <button type="submit" class="btn btn-default add-to-cart">
                                                <a><i class="fa fa-shopping-cart"></i>Thêm giỏ hàng</a>
                                            </button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Application_BichMan\xampp\htdocs\vyshop\resources\views/pages/product/details_product.blade.php ENDPATH**/ ?>