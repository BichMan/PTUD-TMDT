
<?php $__env->startSection('cart_content'); ?>
    <?php $__currentLoopData = $post; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="breadcrumbs">
            <ol class="breadcrumb">
                <li><a href="<?php echo e(URL::to('/')); ?>">Trang chủ</a></li>
                <li><a
                        href="<?php echo e(URL::to('/danh-muc-bai-viet/' . $p->cate_post->cate_post_slug)); ?>"><?php echo e($p->cate_post->cate_post_name); ?></a>
                </li>
            </ol>
        </div>
        <div class="features_items">
            <h1 class="text-left"><?php echo e($meta_title); ?></h1>

            <div class="single-products">
                <?php echo $p->post_content; ?>

            </div>
            <div class="text-right">
                <ul class="nav nav-pills">
                    <li>
                        <div class="fb-share-button" data-href="http://localhost/vyshop/" data-layout="button_count"
                            data-size="small"><a target="_blank"
                                href="https://www.facebook.com/sharer/sharer.php?u=<?php echo e($url_canonical); ?>;src=sdkpreparse"
                                class="fb-xfbml-parse-ignore">Chia sẻ</a></div>
                    </li>
                    <li>
                        <div class="fb-like" data-href="<?php echo e($url_canonical); ?>" data-width=""
                            data-layout="button_count" data-action="like" data-size="small" data-share="false">
                        </div>
                    </li>
                </ul>
            </div>
            <div class="clearfix"></div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout_cart', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Application_BichMan\xampp\htdocs\vyshop\resources\views/pages/post/post.blade.php ENDPATH**/ ?>