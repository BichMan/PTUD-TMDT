
<?php $__env->startSection('content'); ?>
    <div class="features_items">
        <h2 class="title text-center">Sản phẩm bạn đang tìm</h2>
        <?php $__currentLoopData = $search_product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a href="<?php echo e(URL::to('/chi-tiet-san-pham/' . $product->meta_keywords)); ?>">
                <div class="col-sm-4">
                    <div class="product-image-wrapper">
                        <div class="single-products">
                            <div class="productinfo text-center">
                                <form action="<?php echo e(URL::to('/save-cart')); ?>" method="post">
                                    <?php echo e(csrf_field()); ?>

                                    <img src="<?php echo e(URL::to('public/uploads/product/' . $product->product_image)); ?>" alt="" />
                                    <input name="productid_hidden" type="hidden" value="<?php echo e($product->product_id); ?>" />
                                    <input name="qty" type="hidden" value="1" />
                                    <h2><?php echo e(number_format($product->product_price) . ' ' . 'vnđ'); ?></h2>
                                    <p><?php echo e($product->product_name); ?></p>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Application_BichMan\xampp\htdocs\vyshop\resources\views/pages/product/search.blade.php ENDPATH**/ ?>