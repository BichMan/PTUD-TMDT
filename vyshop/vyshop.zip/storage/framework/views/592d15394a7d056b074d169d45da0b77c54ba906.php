
<?php $__env->startSection('admin_content'); ?>
    <div class="table-agile-info">
        <div class="panel panel-default">
            <div class="panel-heading">
                Liệt kê Slider
            </div>
            
            <div class="table-responsive">
                <table class="table table-striped b-t b-light">
                    <thead>
                        <tr>
                            <th style="width:20px;">
                                <label class="i-checks m-b-none">
                                    <input type="checkbox"><i></i>
                                </label>
                            </th>
                            <th>Tên Slide</th>
                            <th>Hình ảnh</th>
                            <th>Mô tả</th>
                            <th>Trạng thái</th>
                            <th style="width:30px;"></th>
                        </tr>
                    </thead>
                    <tbody>
                        
                        <?php $__currentLoopData = $all_slider; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><label class="i-checks m-b-none"><input type="checkbox" name="post[]"><i></i></label>
                                </td>
                                <td><?php echo e($slider->slider_name); ?></td>
                                <td><img src="public/uploads/slider/<?php echo e($slider->slider_image); ?>" height="100" width="350">
                                </td>
                                <td><?php echo e($slider->slider_desc); ?></td>
                                <td><span class="text-ellipsis">
                                        <?php
								if($slider->slider_status ==0){
							?>
                                        <a href="<?php echo e(URL::to('/unactive-slider/' . $slider->slider_id)); ?>"><span
                                                class=" fa-thumbs-styling fa fa-thumbs-up"></span></a>
                                        <?php
								}else{
							?>
                                        <a href="<?php echo e(URL::to('/active-slider/' . $slider->slider_id)); ?>"><span
                                                class="fa-thumbs-styling fa fa-thumbs-down"></span></a>
                                        <?php
							}
							?>
                                    </span></td>
                                <td>
                                    <a onclick="return confirm('Bạn có chắc rằng muốn xóa mục này?')"
                                        href="<?php echo e(URL::to('/delete-slider/' . $slider->slider_id)); ?>"
                                        class="active styling-edit" ui-toggle-class="">
                                        <i class="fa fa-times text-danger text"></i></a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            <footer class="panel-footer">
                <div class="row">
                    <div class="col-sm-5 text-left">
                        <ul class="pagination pagination-sm m-t-none m-b-none">
                            <?php echo $all_slider->links('paginate'); ?>

                        </ul>
                    </div>
                </div>
            </footer>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Application_BichMan\xampp\htdocs\vyshop\resources\views/admin/slider/list_slider.blade.php ENDPATH**/ ?>