
<?php $__env->startSection('cart_content'); ?>
    <div class="features_items">
        <h2 class="title text-center"><?php echo e($meta_title); ?></h2>
        <?php $__currentLoopData = $post; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a href="<?php echo e(URL::to('/bai-viet/' . $p->post_slug)); ?>">
                <div class="product-image-wrapper">
                    <div class="single-products">
                        <div class="productinfo" style="margin:10px">
                            <img style="width:25%;height:160px;float: left; padding:5px"
                                src="<?php echo e(URL::to('public/uploads/post/' . $p->post_image)); ?>"
                                alt="<?php echo e($p->post_slug); ?>" />
                            <h4><?php echo e($p->post_title); ?></h4>
                            <p><?php echo e($p->post_desc); ?></p>
                            <div class="productinfo text-right">
                                <a href="<?php echo e(URL::to('/bai-viet/' . $p->post_slug)); ?>" value="Xem bài viết">Xem bài
                                    viết</a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="clearfix"></div>
            </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout_cart', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Application_BichMan\xampp\htdocs\vyshop\resources\views/pages/post/category_post.blade.php ENDPATH**/ ?>