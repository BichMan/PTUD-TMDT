
<?php $__env->startSection('cart_content'); ?>
    <section id="cart_items">
        <div class="container">
            <div class="breadcrumbs">
                <ol class="breadcrumb">
                    <li><a href="<?php echo e(URL::to('/')); ?>">Trang chủ</a></li>
                    <li class="active">Thanh toán giỏ hàng</li>
                </ol>
            </div>
            <!--/breadcrums-->
            <div class="review-payment">
                <h2>Xem lại giỏ hàng</h2>
            </div>
            <div class="table-responsive cart_info">
                <?php
                $content = Cart::content();
                ?>
                <table class="table table-condensed">
                    <thead>
                        <tr class="cart_menu">
                            <td class="image">Ảnh</td>
                            <td class="description">Sản phẩm</td>
                            <td class="price">Giá</td>
                            <td class="quantity">Số lượng</td>
                            <td class="total">Tổng tiền</td>
                            <td></td>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $content; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v_content): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="cart_product">
                                    <a href=""><img
                                            src="<?php echo e(URL::to('public/uploads/product/' . $v_content->options->image)); ?>"
                                            width="50" alt=""></a>
                                </td>
                                <td class="cart_description">
                                    <h4><a href=""><?php echo e($v_content->name); ?></a></h4>
                                    
                                </td>
                                <td class="cart_price">
                                    <p><?php echo e(number_format($v_content->price) . ' ' . 'vnđ'); ?></p>
                                </td>
                                <td class="cart_quantity">
                                    <div class="cart_quantity_button">
                                        <form action="<?php echo e(URL::to('/update-quantity-cart')); ?>" method="POST">
                                            <?php echo e(csrf_field()); ?>

                                            <input class="cart_quantity_input" type="text" name="cart_quantity"
                                                value="<?php echo e($v_content->qty); ?>" size="2">
                                            <input type="hidden" value="<?php echo e($v_content->rowId); ?>" name="rowId_cart"
                                                class="form-control">
                                            <input type="submit" value="Cập nhật" name="update_qty"
                                                class="btn btn-default btn-sm">
                                        </form>
                                    </div>
                                </td>
                                <td class="cart_total">
                                    <p class="cart_total_price">
                                        <?php
                                        $subtotal = $v_content->price * $v_content->qty;
                                        echo number_format($subtotal) . ' ' . 'vnđ';
                                        ?>
                                    </p>
                                </td>
                                <td class="cart_delete">
                                    <a class="cart_quantity_delete"
                                        href="<?php echo e(URL::to('/delete-cart/' . $v_content->rowId)); ?>"><i
                                            class="fa fa-times"></i></a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </tbody>
                    <tbody>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td class="cart_price">
                            <p>Thành tiền: <?php echo e(Cart::total(0, ',', '.') . ' ' . 'vnđ'); ?></p>
                        </td>
                    </tbody>
                </table>
            </div>

            <h4 style="margin: 50px 0;font-size: 20px;">Chọn hình thức thanh toán</h4>
            <form action="<?php echo e(URL::to('/order-place')); ?>" method="POST">
                <?php echo e(csrf_field()); ?>

                <div class="payment-options">
                    <span>
                        <label><input type="radio" name="payment_option" value="2"> Thanh toán khi nhận hàng</label>
                    </span>
                    <input type="submit" value="Đặt hàng" class="btn btn-primary btn-sm" name="send_oder_place"
                        style="margin-top:0">
                    <?php
                    $message_dathang = Session::get('message_dathang'); //get lấy message đã put
                    if ($message_dathang) {
                        echo '<a>', $message_dathang . '</a>';
                        Session::put('message_dathang', null);
                    }
                    ?>
                    <?php
                    $message_giohang = Session::get('message_giohang'); //get lấy message đã put
                    if ($message_giohang) {
                        echo '<a>', $message_giohang . '</a>';
                        Session::put('message_giohang', null);
                    }
                    ?>
                    <span>
                        <?php
                            $change = Cart::total(0, ',', '');
                            $vnd_to_usd = $change / 23030;
                        ?>
                        <?php if(Cart::content() == '[]'): ?>
                            <?php
                            $message_giohang = Session::get('message_giohang'); //get lấy message đã put
                            if ($message_giohang) {
                                echo '<a>', $message_giohang . '</a>';
                                Session::put('message_giohang', null);
                            }
                            ?>
                        <?php else: ?>
                            <div id="paypal-button"></div>
                            <input type="hidden" id="vnd_to_usd" value="<?php echo e(round($vnd_to_usd, 2)); ?>">
                        <?php endif; ?>
                    </span>
                </div>
            </form>


            
        </div>
    </section>
    <!--/#cart_items-->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout_cart', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Application_BichMan\xampp\htdocs\vyshop\resources\views/pages/Checkout_Account/payment.blade.php ENDPATH**/ ?>