
<?php $__env->startSection('admin_content'); ?>
    <div class="table-agile-info">
        <div class="panel panel-default">
            <div class="panel-heading">
                Thông tin đơn hàng và quá trình vận chuyển
            </div>
            <div class="table-responsive">
                <table class="table table-striped b-t b-light">
                    <thead>
                        <tr>
                            <th>Tên người nhận</th>
                            <th>Số điện thoại</th>
                            <th>Địa chỉ</th>
                            <th>Ghi chú</th>
                            <th>Tên sản phẩm</th>
                            <th>Số lượng</th>
                            <th>Giá</th>
                            <th>Tổng tiền</th>
                            <th>Tình trạng</th>
                            <th>Thanh toán</th>
                            <th style="width:30px"></th>
                        </tr>
                    </thead>
                    <tbody>
                        
                        <tr>
                            <td><?php echo e($order_by_id->shipping_name); ?></td>
                            <td><?php echo e($order_by_id->shipping_phone); ?></td>
                            <td><?php echo e($order_by_id->shipping_address); ?></td>
                            <td><?php echo e($order_by_id->shipping_note); ?></td>
                            <td>
                                <?php $__currentLoopData = $order_pro; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $pro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li style="list-style-type: none;"><?php echo e($pro->product_name); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </td>
                            <td>
                                <?php $__currentLoopData = $order_pro; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $pro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li style="list-style-type: none;"><?php echo e($pro->product_sales_quatity); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </td>
                            <td>
                                <?php $__currentLoopData = $order_pro; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $pro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li style="list-style-type: none;"><?php echo e($pro->product_price); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </td>
                            <td><?php echo e($order_by_id->order_total); ?></td>
                            <td>
                                <?php if($order_by_id->order_status == 0): ?>
                                    <p>Chờ xử lý</p>
                                <?php elseif($order_by_id->order_status == 1): ?>
                                    <p>Đang đóng gói</p>
                                <?php elseif($order_by_id->order_status == 2): ?>
                                    <p>Đã chuyển giao đến đơn vị vẫn chuyển</p>
                                <?php elseif($order_by_id->order_status == 3): ?>
                                    <p>Đã giao hàng thành công</p>
                                <?php else: ?>
                                    <p>Đơn hàng đã hủy</p>
                                <?php endif; ?>
                            </td>
                            <td><?php echo e($order_by_id->payment_status); ?></td>
                            <td>
                                <a href="<?php echo e(URL::to('/edit-order-status/' . $order_by_id->order_id)); ?>"
                                    class="active styling-edit" ui-toggle-class="">
                                    <i class="fa fa-pencil-square-o text-success text-active"></i></a>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Application_BichMan\xampp\htdocs\vyshop\resources\views/admin/order_details/view_order.blade.php ENDPATH**/ ?>