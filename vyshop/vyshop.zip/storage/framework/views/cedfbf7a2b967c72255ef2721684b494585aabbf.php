
<?php $__env->startSection('admin_content'); ?>
    <div class="table-agile-info">
        <div class="panel panel-default">
            <div class="panel-heading">
                Liệt kê danh mục Bài viết
            </div>
            <div class="table-responsive">
                <table class="table table-striped b-t b-light">
                    <thead>
                        <tr>
                            <th style="width:20px;">
                                <label class="i-checks m-b-none">
                                    <input type="checkbox"><i></i>
                                </label>
                            </th>
                            <th>Tên danh mục bài viết</th>
                            <th>Hiển thị</th>
                            <th style="width:30px;"></th>
                        </tr>
                    </thead>
                    <tbody>
                        
                        <?php $__currentLoopData = $all_category_post; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $all_cate_post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><label class="i-checks m-b-none"><input type="checkbox" name="post[]"><i></i></label>
                                </td>
                                <td><?php echo e($all_cate_post->cate_post_name); ?></td>
                                <td><span class="text-ellipsis">
                                        <?php
								if($all_cate_post->cate_post_status ==0){
							?>
                                        <a href="<?php echo e(URL::to('/unactive-category-post/' . $all_cate_post->cate_post_id)); ?>"><span
                                                class=" fa-thumbs-styling fa fa-thumbs-up"></span></a>
                                        <?php
								}else{
							?>
                                        <a href="<?php echo e(URL::to('/active-category-post/' . $all_cate_post->cate_post_id)); ?>"><span
                                                class="fa-thumbs-styling fa fa-thumbs-down"></span></a>
                                        <?php
							}
							?>
                                    </span></td>
                                <td>
                                    <a href="<?php echo e(URL::to('/edit-category-post/' . $all_cate_post->cate_post_id)); ?>"
                                        class="active styling-edit" ui-toggle-class="">
                                        <i class="fa fa-pencil-square-o text-success text-active"></i></a>
                                    <a onclick="return confirm('Bạn có chắc rằng muốn xóa mục này?')"
                                        href="<?php echo e(URL::to('/delete-category-post/' . $all_cate_post->cate_post_id)); ?>"
                                        class="active styling-edit" ui-toggle-class="">
                                        <i class="fa fa-times text-danger text"></i></a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            <footer class="panel-footer">
                <div class="row">
                    <div class="col-sm-5 text-left">
                        <ul class="pagination pagination-sm m-t-none m-b-none">
                            <?php echo $all_category_post->links('paginate'); ?>

                        </ul>
                    </div>
                </div>
            </footer>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Application_BichMan\xampp\htdocs\vyshop\resources\views/admin/category_post/all_category_post.blade.php ENDPATH**/ ?>