
<?php $__env->startSection('admin_content'); ?>
    <div class="row">
        <div class="col-lg-12">
            <section class="panel">
                <header class="panel-heading">
                    Cập nhật tình trạng giao hàng
                </header>
                <div class="panel-body">
                    
                        <div class="position-center">
                            <?php $__currentLoopData = $edit_order_status; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $ed): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <form role="form" action="<?php echo e(URL::to('/update-order-status/' . $ed->order_id)); ?>"
                                method="post">
                                <?php echo e(csrf_field()); ?>

                                <div class="form-group">
                                    <label for="exampleInputEmail1">Tình trạng đơn hàng</label>
                                    <select name="order_status" class="form-control input-sm m-bot15">
                                        <option value="0">Chờ xử lý</option>
                                        <option value="1">Đang đóng gói</option>
                                        <option value="2">Đã chuyển giao đến đơn vị vẫn chuyển</option>
                                        <option value="3">Đã giao hàng thành công</option>
                                        <option value="4">Hủy đơn hàng</option>
                                    </select>
                                </div>
                                <button type="submit" name="update_order_status" class="btn btn-info">Cập nhật</button>
                            </form>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    
                </div>
            </section>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Application_BichMan\xampp\htdocs\vyshop\resources\views/admin/order_details/edit_order_status.blade.php ENDPATH**/ ?>