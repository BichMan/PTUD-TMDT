
<?php $__env->startSection('admin_content'); ?>
    <div class="table-agile-info">
        <div class="panel panel-default">
            <div class="panel-heading">
                Liệt kê đơn hàng
            </div>
            <div class="table-responsive">
                <table class="table table-striped b-t b-light">
                    <thead>
                        <tr>
                            <th style="width:20px;">
                                <label class="i-checks m-b-none">
                                    <input type="checkbox"><i></i>
                                </label>
                            </th>
                            <th>Tên người đặt hàng</th>
                            <th>Tổng tiền</th>
                            <th>Tình trạng đơn hàng</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody>
                        
                        <?php $__currentLoopData = $all_order; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <tr>
                                <td><label class="i-checks m-b-none"><input type="checkbox" name="post[]"></label></td>
                                <td><?php echo e($order->shipping_name); ?></td>
                                <td><?php echo e($order->order_total); ?></td>
                                <td>
                                    <?php if($order->order_status == 0): ?>
                                    <p>Chờ xử lý</p>
                                    <?php elseif($order->order_status == 1): ?>
                                    <p>Đang đóng gói</p>
                                    <?php elseif($order->order_status == 2): ?>
                                    <p>Đã chuyển giao đến đơn vị vẫn chuyển</p>
                                    <?php elseif($order->order_status == 3): ?>
                                    <p>Đã giao hàng thành công</p>
                                    <?php else: ?>
                                    <p>Đơn hàng đã hủy</p>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <a href="<?php echo e(URL::to('/view-order/' . $order->order_id)); ?>" class="active styling-edit">
										<i class="fa fa-eye" aria-hidden="true"></i>
                                    </a>
                                </td>
                            </tr>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            <footer class="panel-footer">
                <div class="row">
                    <div class="col-sm-5 text-left">
                        <ul class="pagination pagination-sm m-t-none m-b-none">
                            <?php echo $all_order->links('paginate'); ?>

                        </ul>
                    </div>
                </div>
            </footer>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Application_BichMan\xampp\htdocs\vyshop\resources\views/admin/order_details/manage_order.blade.php ENDPATH**/ ?>