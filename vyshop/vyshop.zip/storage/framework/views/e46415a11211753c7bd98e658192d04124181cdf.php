<!DOCTYPE html>
<html lang="en">
    <head>
        <meta name="viewport" content="width=device-width, initial-">
        <title>Gửi mail google</title>
    </head>
    <body>
        <h1>Mail được gửi từ: <?php echo e($name); ?></h1>
        <h3>Với nội dung là <?php echo e($body); ?></h3>
    </body>
</html><?php /**PATH E:\Application_BichMan\xampp\htdocs\vyshop\resources\views/pages/send_mail.blade.php ENDPATH**/ ?>