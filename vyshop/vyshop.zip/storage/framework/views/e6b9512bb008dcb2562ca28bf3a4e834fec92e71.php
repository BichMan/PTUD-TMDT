
<?php $__env->startSection('cart_content'); ?>
    <section id="cart_items">
        <div class="container">
            <div class="breadcrumbs">
                <ol class="breadcrumb">
                    <li><a href="<?php echo e(URL::to('/')); ?>">Trang chủ</a></li>
                    <li class="active">Thông tin đặt hàng</li>
                </ol>
            </div>
            <div class="review-payment">
                <h2>Bạn đã đặt hàng thành công và đơn hàng của bạn đang được xử lý!</h2>
                <h2>Cảm ơn đã chọn chúng tôi!</h2>
            </div>

        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout_cart', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Application_BichMan\xampp\htdocs\vyshop\resources\views/pages/Checkout_Account/handcash.blade.php ENDPATH**/ ?>